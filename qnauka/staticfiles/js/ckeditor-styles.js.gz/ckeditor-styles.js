CKEDITOR.stylesSet.add('mystyles', [

    { name: 'Párrafo sin margen', element: 'p', attributes: { 'class': 'p-nomargin' } },
    { name: 'Enlace opinión', element: 'p', attributes: { 'class': 'opinion__link' } },
    { name: 'Enlace opinión2', element: 'p', attributes: { 'class': 'opinion__link--linea' } },
])